		       README.TXT			

  		MyOra � Version 5.1

Copyright (C) 2016 Jayam Systems, LLC. All rights reserved. 
================================================================================

Thank you for your interest in MyOra Software.


1. Date of Release

January 13, 2016


2. Introduction

MyOra is a SQL Tool for Oracle database developers and DBAs. This tool is used for 
Oracle application development and Oracle database monitoring.


3. MyOra version 5.1

This fully functional free version of MyOra will expire on July 15, 2016. 
A new version will be available just before the expiration date. MyOra is
entirely written by Kris Murthy. All components of MyOra are built from 
ground-up. 


4. Requirements for MyOra

Requires java 1.5 or later version of java.
Requires Oracle JDBC Thin driver ojdbc14.jar or ojdbc5.jar or ojdbc6.jar.
No installation required for Oracle JDBC driver. 
No Oracle client required.
No installation required for MyOra.
No need to access Active Session History or ASH table.
No need to acesss Automatic Workload Repository or AWR tables.
No need to access DBA history tables.


5. Oracle versions supported

Oracle 9i, 10g, 11g, 12c
		

6. MyOra zip File

MyOra is distributed as a zip file only. Using WinZip (or any compression 
application) extract all the files from MyOra zip file into a folder. MyOra zip 
file contains the following files.

	 - LICENSE.TXT
	 - README.TXT
 	 - MyOra.exe
      
  The approximate size of MyOra application jar file is  1 MB. 
 

7. License File

MyOra will create an evaluation510.lic and userkey510.lic upon the first use of MyOra.


8. Running MyOra

MyOra 5.1 runs on Windows only. MyOra requires java 1.5 or later version of java. 
Please make sure you have java 1.5 or later Java Runtime Environment (JRE) 
installed on the local computer. 

MyOra 5.1 requires Oracle JDBC driver ojdbc14.jar or ojdbc5.jar or ojdbc6.jar.
No installation required for Oracle JDBC driver.
Please download Oracle JDBC driver from Oracle's website and copy it to the folder
where MyOra.exe file is located.

If you have Java 1.5 (JRE) version installed on your local computer, then you need 
ojdbc14.jar or ojdbc5.jar

If you have Java 1.6 (JRE) version installed on your local computer, then you need 
ojdbc14.jar or ojdbc5.jar or ojdbc6.jar
        
To run MyOra application
 - Double click the file MyOra.exe

   MyOra has been tested on Windows XP, Windows 7 and Windows 8.  
 

9. Getting Started

After MyOra is started, the main window appears with a login screen. 
The login screen prompts for database connection fields. (Hostname, Database, 
UserName, password and other Oracle connection related fields).
	

10. Digitally Signed

MyOra jar file is digitally signed and the identity is verified by VeriSign Inc.
	 
	    	 
11. Acknowledgements

Oracle is a registered trademark of Oracle Corporation.

Java and all Java-based marks are trademarks or registered trademarks of 
Sun Microsystems, Inc. in the U.S. and other countries.

MyOra is a registered trademark of Jayam Systems, LLC.

Any other trademarks or service marks contained herein are the property 
of their respective owners.


12. Contact information

For any questions about MyOra, send your email to info@jayamsystems.com

MyOra Website: http://www.MyOraSQL.com


--------------------------------
End of README.TXT
